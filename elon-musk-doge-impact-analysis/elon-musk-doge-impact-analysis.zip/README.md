# Elon Musk Dogecoin Impact Analysis

This project investigates how Elon Musk's tweets and media appearances influence Dogecoin prices using time series data, sentiment analysis, and interactive visualizations.

## Features
- 📈 Fetch DOGE price and Elon Musk tweets
- 🧠 Sentiment analysis using VADER
- 🔗 Correlation between tweets/news and price spikes
- 📊 Streamlit dashboard for interactive exploration

## Stack
- CoinGecko API, Tweepy (Twitter API)
- VADER Sentiment
- Streamlit, Pandas, Seaborn

Run the dashboard:
```bash
cd app
streamlit run app.py
```
